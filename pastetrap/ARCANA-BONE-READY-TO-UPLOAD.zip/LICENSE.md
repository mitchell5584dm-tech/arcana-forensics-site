# Business Source License 1.1 - ARCANA Forensics / PASTE TRAP - Bone Edition

Copyright 2026 ARCANA Forensics / David Mitchell

Licensor: ARCANA Forensics

Licensed Work: ARCANA Forensics Toolkit + PASTE TRAP Kit

Change Date: 2030-01-01
Change License: MIT License

## Terms

1. You may use this work for Personal Use and Small Business Use (under 50 seats) internally.

2. You may NOT:
- Redistribute, resell, or sublicense the work
- Host as a service / SaaS for others
- Remove watermarks / attribution
- Publish the kit as your own product

3. Source-Available: You get readable source for verification and offline use. Not Open Source (OSI).

4. Bone Pricing: $19 Paste Trap, $29 Toolkit Lifetime, $39 Full Bundle. Price is intentionally low to drive adoption. No refunds on digital bone pricing, but you get lifetime updates.

This is not legal advice. Educational security awareness tool. No warranty. Use at own risk.

Contact: trap@arcana-forensics.com
