# Disclaimer
Offline-first, no warranty. For educational / awareness use. Real errors never ask you to paste. Always verify. Use at own risk.
